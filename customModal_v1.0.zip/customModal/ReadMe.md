Thank You
---
Thank you for downloading **Custom Modal Alert** v1.0

⚠️ Important ⚠️
---
Unzip the **customModal_v1.0.zip** into your root folder

```
/root
├── assets📁
│       ├── css📁
│       │   └── style.css📝
│       └── js📁
│           └── script.js📝
├── customModal_v1.0 (unzipped folder)
└── index.html📝
```
