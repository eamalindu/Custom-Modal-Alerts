Thank You
---
Thank you for downloading **Custom Modal Alert** v2.0

⚠️ Important ⚠️
---
Unzip the **customModal_v2.0.zip** into your root folder

```
/root
├── assets📁
│       ├── css📁
│       │   └── style.css📝
│       └── js📁
│           └── script.js📝
├── customModal_v2.0 (unzipped folder)
└── index.html📝
```
